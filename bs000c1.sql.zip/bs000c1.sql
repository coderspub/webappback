-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 19, 2019 at 03:08 PM
-- Server version: 5.7.26-0ubuntu0.18.04.1
-- PHP Version: 7.2.17-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bs000c1`
--

-- --------------------------------------------------------

--
-- Table structure for table `tracking_details`
--

CREATE TABLE `tracking_details` (
  `id` int(11) NOT NULL,
  `app_id` varchar(100) NOT NULL,
  `latitude` varchar(100) NOT NULL,
  `longitude` varchar(100) NOT NULL,
  `speed` varchar(50) DEFAULT NULL,
  `ideal_status` varchar(100) DEFAULT NULL,
  `datetime` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tracking_details`
--

INSERT INTO `tracking_details` (`id`, `app_id`, `latitude`, `longitude`, `speed`, `ideal_status`, `datetime`) VALUES
(1, 'a1', '13.54665', '80.3456', '', '', ''),
(2, 'a1', '0', '1', NULL, NULL, NULL),
(3, 'a1', '1', '2', NULL, NULL, NULL),
(4, 'a1', '0', '1', NULL, NULL, NULL),
(5, 'a1', '1', '2', NULL, NULL, NULL),
(6, 'a1', '2', '3', NULL, NULL, NULL),
(7, 'a1', '3', '4', NULL, NULL, NULL),
(8, 'a1', '4', '5', NULL, NULL, NULL),
(9, 'a1', '5', '6', NULL, NULL, NULL),
(10, 'a1', '6', '7', NULL, NULL, NULL),
(11, 'a1', '7', '8', NULL, NULL, NULL),
(12, 'a1', '8', '9', NULL, NULL, NULL),
(13, 'a1', '9', '10', NULL, NULL, NULL),
(14, 'a1', '10', '11', NULL, NULL, NULL),
(15, 'a1', '11', '12', NULL, NULL, NULL),
(16, 'a1', '12', '13', NULL, NULL, NULL),
(17, 'a1', '13', '14', NULL, NULL, NULL),
(18, 'a1', '14', '15', NULL, NULL, NULL),
(19, 'a1', '15', '16', NULL, NULL, NULL),
(20, 'a1', '16', '17', NULL, NULL, NULL),
(21, 'a1', '17', '18', NULL, NULL, NULL),
(22, 'a1', '18', '19', NULL, NULL, NULL),
(23, 'a1', '19', '20', NULL, NULL, NULL),
(24, 'a1', '20', '21', NULL, NULL, NULL),
(25, 'a1', '21', '22', NULL, NULL, NULL),
(26, 'a1', '22', '23', NULL, NULL, NULL),
(27, 'a1', '23', '24', NULL, NULL, NULL),
(28, 'a1', '24', '25', NULL, NULL, NULL),
(29, 'a1', '25', '26', NULL, NULL, NULL),
(30, 'a1', '26', '27', NULL, NULL, NULL),
(31, 'a1', '27', '28', NULL, NULL, NULL),
(32, 'a1', '28', '29', NULL, NULL, NULL),
(33, 'a1', '29', '30', NULL, NULL, NULL),
(34, 'a1', '30', '31', NULL, NULL, NULL),
(35, 'a1', '31', '32', NULL, NULL, NULL),
(36, 'a1', '32', '33', NULL, NULL, NULL),
(37, 'a1', '33', '34', NULL, NULL, NULL),
(38, 'a1', '34', '35', NULL, NULL, NULL),
(39, 'a1', '35', '36', NULL, NULL, NULL),
(40, 'a1', '36', '37', NULL, NULL, NULL),
(41, 'a1', '37', '38', NULL, NULL, NULL),
(42, 'a1', '38', '39', NULL, NULL, NULL),
(43, 'a1', '39', '40', NULL, NULL, NULL),
(44, 'a1', '40', '41', NULL, NULL, NULL),
(45, 'a1', '41', '42', NULL, NULL, NULL),
(46, 'a1', '42', '43', NULL, NULL, NULL),
(47, 'a1', '43', '44', NULL, NULL, NULL),
(48, 'a1', '44', '45', NULL, NULL, NULL),
(49, 'a1', '45', '46', NULL, NULL, NULL),
(50, 'a1', '46', '47', NULL, NULL, NULL),
(51, 'a1', '47', '48', NULL, NULL, NULL),
(52, 'a1', '48', '49', NULL, NULL, NULL),
(53, 'a1', '49', '50', NULL, NULL, NULL),
(54, 'a1', '50', '51', NULL, NULL, NULL),
(55, 'a1', '51', '52', NULL, NULL, NULL),
(56, 'a1', '52', '53', NULL, NULL, NULL),
(57, 'a1', '53', '54', NULL, NULL, NULL),
(58, 'a1', '54', '55', NULL, NULL, NULL),
(59, 'a1', '55', '56', NULL, NULL, NULL),
(60, 'a1', '56', '57', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tracking_details`
--
ALTER TABLE `tracking_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tracking_details`
--
ALTER TABLE `tracking_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
