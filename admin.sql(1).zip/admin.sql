-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 19, 2019 at 03:07 PM
-- Server version: 5.7.26-0ubuntu0.18.04.1
-- PHP Version: 7.2.17-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_details`
--

CREATE TABLE `app_details` (
  `id` int(11) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `app_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `app_details`
--

INSERT INTO `app_details` (`id`, `customer_id`, `app_id`) VALUES
(1, 'BS000C1', 'BS000C100TN13K99870001'),
(2, 'BS000C1', 'BS000C100TN13T95260002'),
(3, 'BS000C1', 'BS000C100TN15K52180003'),
(4, 'BS000C1', 'BS000C100TN23K55180004'),
(5, 'BS000C1', 'BS000C100TN15K85960005'),
(6, 'BS000C2', 'BS000C200TN17K76540001'),
(7, 'BS000C2', 'BS000C200TN17K85960002'),
(8, 'BS000C2', 'BS000C200TN17K85260003'),
(9, 'BS000C2', 'BS000C200TN18K76540004'),
(10, 'BS000C2', 'BS000C200TN12K76540005'),
(11, 'BS000C2', 'BS000C200TN23K76540006'),
(12, 'BS000C2', 'BS000C200TN17K76540007');

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE `customer_details` (
  `id` int(11) NOT NULL,
  `customer_id` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_number` varchar(20) NOT NULL,
  `customer_address` varchar(150) NOT NULL,
  `purpose` varchar(100) NOT NULL,
  `no.of users` int(11) NOT NULL,
  `registered_date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`id`, `customer_id`, `password`, `customer_name`, `customer_number`, `customer_address`, `purpose`, `no.of users`, `registered_date`) VALUES
(1, 'BS000C1', 'bbb', 'BrainStack', '8825753162', 'No:9/877, Anjugam Nagar, Vadapalani, Ch-45', 'Trade', 5, '14-03-2019 Z 12:45:33T'),
(2, 'BS000C2', 'ccc', 'Coovum', '9925753162', 'No:23, Jeshwanth Nagar, Mogappair West, Ch-37', 'Travels', 7, '11-02-2019 Z 18:55:03T');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_details`
--

CREATE TABLE `vehicle_details` (
  `id` int(11) NOT NULL,
  `app_id` varchar(100) NOT NULL,
  `vehicle_type` varchar(50) NOT NULL,
  `vehicle_no` varchar(50) NOT NULL,
  `vehicle_image` varchar(100) NOT NULL,
  `vehicle_document` varchar(100) NOT NULL,
  `registered_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle_details`
--

INSERT INTO `vehicle_details` (`id`, `app_id`, `vehicle_type`, `vehicle_no`, `vehicle_image`, `vehicle_document`, `registered_date`) VALUES
(1, 'BS000C100TN13K99870001', 'Mini Truck', 'TN13K9987', '', '', ''),
(2, 'BS000C100TN13T95260002', 'Mini Truck', 'TN13T9526', '', '', ''),
(3, 'BS000C100TN15K52180003', 'Mini Truck', 'TN15K5218', '', '', ''),
(4, 'BS000C100TN23K55180004', 'Lorry', 'TN23K5518', '', '', ''),
(5, 'BS000C100TN15K85960005', 'Lorry', 'TN15K8596', '', '', ''),
(6, 'BS000C200TN17K76540001', 'Car', 'TN17K7654', '', '', ''),
(7, 'BS000C200TN17K85960002', 'Car', 'TN17K8596', '', '', ''),
(8, 'BS000C200TN17K85260003', 'Van', 'TN17K8526', '', '', ''),
(9, 'BS000C200TN18K76540004', 'Van', 'TN18K7654', '', '', ''),
(10, 'BS000C200TN12K76540005', 'Car', 'TN12K7654', '', '', ''),
(11, 'BS000C200TN23K76540006', 'Van', 'TN23K7654', '', '', ''),
(12, 'BS000C200TN17K76540007', 'Van', 'TN17K7654', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_details`
--
ALTER TABLE `app_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_details`
--
ALTER TABLE `customer_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_details`
--
ALTER TABLE `vehicle_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer_details`
--
ALTER TABLE `customer_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
